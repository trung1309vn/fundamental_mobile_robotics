### Group Name: 
optional 

### 1st Student:
Trung Nguyen, 151785355

### 2nd Student:
Noora Sassali, H299753 

### Comments:
Please share your comments and opinions here.
